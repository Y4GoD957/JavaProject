package br.com.barbearia.barber.web.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.barbearia.barber.web.dtos.ProdutoForm;
import br.com.barbearia.barber.web.dtos.FlashMessage;
import br.com.barbearia.barber.web.services.WebProdutoServices;

@Controller
@RequestMapping("/admin/produto")
public class ProdutoController {

  @Autowired
  private WebProdutoServices service;

  @GetMapping
  public ModelAndView buscarTodos() {
    var modelAndView = new ModelAndView("admin/produto/lista");

    modelAndView.addObject("produto", service.buscarTodos());

    return modelAndView;
  }

  @GetMapping("/cadastrar")
  public ModelAndView cadastrar() {
    var modelAndView = new ModelAndView("admin/produto/produto-form");

    modelAndView.addObject("produtoForm", new ProdutoForm());

    return modelAndView;
  }

  @PostMapping("/cadastrar")
  public String cadastrar(@Valid @ModelAttribute("produtoForm") ProdutoForm form, BindingResult result, RedirectAttributes attrs) {
    if (result.hasErrors()) {
      return "admin/produto/produto-form";
    }
    
    service.cadastrar(form);
    attrs.addFlashAttribute("alert", new FlashMessage("alert-success", "Produto cadastrado com sucesso!"));

    return "redirect:/admin/produto";
  }

  @GetMapping("/{CodPro}/editar")
  public ModelAndView editar(@PathVariable Long CodPro) {
    var modelAndView = new ModelAndView("admin/produto/produto-form");

    modelAndView.addObject("produtoForm", service.buscarPorId(CodPro));

    return modelAndView;
  }

  @PostMapping("/{CodPro}/editar")
  public String editar(@PathVariable Long CodPro, @Valid @ModelAttribute("produtoForm") ProdutoForm form, BindingResult result, RedirectAttributes attrs) {
   if (result.hasErrors()){
    return "admin/produto/produto-form";
   }

   service.editar(form, CodPro);
   attrs.addFlashAttribute("alert", new FlashMessage("alert-success", "Produto editado com sucesso!"));

    return "redirect:/admin/produto";
  }

  @GetMapping("/{CodPro}/excluir")
  public String excluir(@PathVariable Long CodPro, RedirectAttributes attrs) {
    service.excluirPorId(CodPro);
    attrs.addFlashAttribute("alert", new FlashMessage("alert-success", "Produto excluido com sucesso!"));

    return "redirect:/admin/produto";
  }

}
