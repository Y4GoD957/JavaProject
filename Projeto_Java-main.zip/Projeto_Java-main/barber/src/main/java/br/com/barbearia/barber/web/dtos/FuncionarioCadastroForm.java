package br.com.barbearia.barber.web.dtos;

import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import br.com.barbearia.barber.core.enums.TipoFuncionario;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table(name = "Funcionario")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FuncionarioCadastroForm {
  
  @NotNull
  @Size(min = 3, max = 255)
  private String nomeCompleto;

  @Email
  @NotNull
  @Size(min = 3, max = 255)
  private String emailFun;
  
  @NotEmpty
  @NotNull
  private String senha;

  @NotEmpty
  @NotNull
  private String confirmacaoSenha;
  
  @Size(min = 3, max = 255)
  private String CepFun;

  @Size(min = 11, max =14)
  private String CpfFun;

  @Size(min = 8, max =20)
  private String FoneFun;

  @NotNull
  private TipoFuncionario tipoFuncionario;
}
