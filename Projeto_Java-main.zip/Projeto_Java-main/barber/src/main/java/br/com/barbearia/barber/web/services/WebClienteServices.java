package br.com.barbearia.barber.web.services;

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.barbearia.barber.core.exceptions.ClienteNaoEncontradoException;
import br.com.barbearia.barber.core.models.Cliente;
import br.com.barbearia.barber.core.repositories.ClienteRepository;
import br.com.barbearia.barber.web.dtos.ClienteForm;
import br.com.barbearia.barber.web.mappers.WebClienteMapper;

@Service
public class WebClienteServices {
  
  @Autowired
  private ClienteRepository repository;

  @Autowired
  private WebClienteMapper mapper;

  public List<Cliente> buscarTodos(){
    return repository.findAll();
  }

  public Cliente cadastrar(ClienteForm form) {
    var model = mapper.toModel(form);

    return repository.save(model);
  }

  public Cliente buscarPorId(Long CodCli) {
    var clienteEncontrado = repository.findById(CodCli);

    if (clienteEncontrado.isPresent()){
      return clienteEncontrado.get();
    }

    var mensagem = String.format("Cliente com ID %d não encontrado", CodCli);
    throw new ClienteNaoEncontradoException(mensagem);
  }

  public Cliente editar(ClienteForm form, Long CodCli){
    var clienteEncontrado = buscarPorId(CodCli);

    var model = mapper.toModel (form);
    model.setCodCli(clienteEncontrado.getCodCli());

    return repository.save(model);
  }

  public void excluirPorId(Long CodCli){
    var clienteEncontrado = buscarPorId(CodCli);

    repository.delete(clienteEncontrado);
  }
}
