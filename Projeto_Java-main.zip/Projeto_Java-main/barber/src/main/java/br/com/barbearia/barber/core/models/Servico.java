package br.com.barbearia.barber.core.models;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Table(name = "Servico")
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(onlyExplicitlyIncluded = true)
public class Servico {
    @EqualsAndHashCode.Include
    @ToString.Include
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "CodSrv")
    private Long CodSrv;

    @Column(name = "TipoSrv")
    private String TipoSrv;

    @Column(name = "ValorSrv")
    private BigDecimal ValorSrv;
    
    @Column(name = "DescSrv")
    private String DescSrv;

    @Column(name = "NomeImagem")
    private String NomeImagem;

}
