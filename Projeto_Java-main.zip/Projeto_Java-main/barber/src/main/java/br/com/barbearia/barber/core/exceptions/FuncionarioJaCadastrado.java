package br.com.barbearia.barber.core.exceptions;

import org.springframework.validation.FieldError;

public class FuncionarioJaCadastrado extends ValidacaoException {

  public FuncionarioJaCadastrado(String message, FieldError fieldError){
    super(message, fieldError);
  }
}
