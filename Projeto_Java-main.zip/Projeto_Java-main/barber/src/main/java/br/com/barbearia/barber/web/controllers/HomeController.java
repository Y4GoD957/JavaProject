package br.com.barbearia.barber.web.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import br.com.barbearia.barber.core.repositories.ProdutoRepository;

@Controller
@RequestMapping("/")
public class HomeController {

  @Autowired
  private ProdutoRepository produtoRepository;

  @GetMapping("/index.html")
  public String indexs(){
    return "index";
  }
  @GetMapping("/services.html")
  public String services(){
    return "services";
  }
  @GetMapping("/products.html")
  public ModelAndView products(){
    ModelAndView mv = new ModelAndView("/products.html");
    mv.addObject("produto",produtoRepository.findAll()) ;   
    return mv;
  }
  @GetMapping("/carrinho.html")
  public ModelAndView carrinho(){
    ModelAndView mv = new ModelAndView("/carrinho.html");
    // mv.addObject("carrinho",produtoRepository.findAll()) ;   
    return mv;
  }
}