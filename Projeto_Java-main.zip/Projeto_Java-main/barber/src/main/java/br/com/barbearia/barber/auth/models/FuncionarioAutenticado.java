package br.com.barbearia.barber.auth.models;

import java.util.Collection;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;

import br.com.barbearia.barber.core.models.Funcionario;
import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public class FuncionarioAutenticado implements UserDetails{

  private Funcionario funcionario;
  
  @Override
  public Collection<? extends GrantedAuthority> getAuthorities() {
   return AuthorityUtils.createAuthorityList(funcionario.getTipoFuncionario().toString());
  }

  @Override
  public String getPassword() {
    return funcionario.getSenha();
  }

  @Override
  public String getUsername() {
    return funcionario.getEmailFun();
  }

  @Override
  public boolean isAccountNonExpired() {
    return true;
  }

  @Override
  public boolean isAccountNonLocked() { 
    return true;
  }

  @Override
  public boolean isCredentialsNonExpired() {
    return true;
  }

  @Override
  public boolean isEnabled() {
    return true;
  }
  
}
