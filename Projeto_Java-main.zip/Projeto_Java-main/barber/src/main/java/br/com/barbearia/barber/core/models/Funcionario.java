package br.com.barbearia.barber.core.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import br.com.barbearia.barber.core.enums.TipoFuncionario;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Table(name = "FUNCIONARIO")
@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(onlyExplicitlyIncluded = true)
@ToString(onlyExplicitlyIncluded = true)
public class Funcionario {
    @EqualsAndHashCode.Include
    @ToString.Include
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long CodFun;

    @Column(name = "nome_completo", nullable = false)
    private String NomeFun;

    @Column(nullable = false, unique = true)
    private String EmailFun;

    @Column(nullable = false)
    private String CepFun;

    @Column(nullable = false)
    private String CpfFun;
    
    @Column(nullable = false)
    private String FoneFun;
    
    @Column(nullable = false)
    private String senha;

    @Column(name = "tipo_funcionario", length = 8, nullable = false)
    @Enumerated(EnumType.STRING)
    private TipoFuncionario tipoFuncionario;
}

