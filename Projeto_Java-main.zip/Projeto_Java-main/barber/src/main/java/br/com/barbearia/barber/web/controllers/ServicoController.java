package br.com.barbearia.barber.web.controllers;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.barbearia.barber.web.dtos.ServicoForm;
import br.com.barbearia.barber.core.models.Servico;
import br.com.barbearia.barber.web.dtos.FlashMessage;
import br.com.barbearia.barber.web.services.WebServicoServices;

@Controller
@RequestMapping("/admin/servico")
public class ServicoController {

  private static String caminhoImagens = "C:/Users/bosco/DEV/ProjetoFinal/imagens/";

  @Autowired
  private WebServicoServices service;

 @GetMapping
public ModelAndView buscarTodos() {
    List<Servico> servicos = service.buscarTodos();
    List<String> nomesImagens = servicos.stream()
        .map(Servico::getNomeImagem)
        .collect(Collectors.toList());

    var modelAndView = new ModelAndView("admin/servico/lista");
    modelAndView.addObject("servico", servicos);
    modelAndView.addObject("nomesImagens", nomesImagens);
    
    return modelAndView;
}



  @GetMapping("/cadastrar")
  public ModelAndView cadastrar() {
    var modelAndView = new ModelAndView("admin/servico/servico-form.html");

    modelAndView.addObject("servicoForm", new ServicoForm());

    return modelAndView;
  }
  
@PostMapping("/cadastrar")
public String cadastrar(@Valid @ModelAttribute("servicoForm") ServicoForm form, BindingResult result,
        @RequestPart("file") MultipartFile arquivo, RedirectAttributes attrs) {
    if (result.hasErrors()) {
        return "admin/servico/servico-form.html";
    }
    
    try {
        if (!arquivo.isEmpty()) {
            byte[] bytes = arquivo.getBytes();
            Path caminho = Paths.get(caminhoImagens + arquivo.getOriginalFilename());
            Files.write(caminho, bytes);
            form.setNomeImagem(arquivo.getOriginalFilename());
        }      
    } catch (IOException e) {
        e.printStackTrace();
    }

    service.cadastrar(form);
    attrs.addFlashAttribute("alert", new FlashMessage("alert-success", "Servico cadastrado com sucesso!"));

    return "redirect:/admin/servico";
}

  @GetMapping("/{CodSrv}/editar")
  public ModelAndView editar(@PathVariable Long CodSrv) {
    var modelAndView = new ModelAndView("admin/servico/servico-form.html");

    modelAndView.addObject("servicoForm", service.buscarPorId(CodSrv));

    return modelAndView;
  }

  @PostMapping("/{CodSrv}/editar")
  public String editar(@PathVariable Long CodSrv, @Valid @ModelAttribute("servicoForm") ServicoForm form,
      BindingResult result,@RequestPart("file") MultipartFile arquivo, RedirectAttributes attrs) {
    if (result.hasErrors()) {
      return "admin/servico/servico-form.html";
    }
    try {
        if (!arquivo.isEmpty()) {
            byte[] bytes = arquivo.getBytes();
            Path caminho = Paths.get(caminhoImagens + arquivo.getOriginalFilename());
            Files.write(caminho, bytes);
            form.setNomeImagem(arquivo.getOriginalFilename());
        }      
    } catch (IOException e) {
        e.printStackTrace();
    }
    service.editar(form, CodSrv);
    attrs.addFlashAttribute("alert", new FlashMessage("alert-success", "Servico editado com sucesso!"));

    return "redirect:/admin/servico";
  }

  @GetMapping("/{CodSrv}/excluir")
  public String excluir(@PathVariable Long CodSrv, RedirectAttributes attrs) {
    service.excluirPorId(CodSrv);
    attrs.addFlashAttribute("alert", new FlashMessage("alert-success", "Servico excluido com sucesso!"));

    return "redirect:/admin/servico";
  }
  
// @GetMapping("/mostrarImagem/{imagem}")
// public ResponseEntity<byte[]> retornarImagem(@PathVariable("imagem") String imagem) throws IOException {

//     File imagemArquivo = new File(caminhoImagens + imagem);
//     if (imagemArquivo.exists()) {
//         byte[] imagemBytes = Files.readAllBytes(imagemArquivo.toPath());
//         HttpHeaders headers = new HttpHeaders();
//         headers.setContentType(MediaType.IMAGE_JPEG);
//         return new ResponseEntity<>(imagemBytes, headers, HttpStatus.OK);
//     }
//     return ResponseEntity.notFound().build();
// }

}
