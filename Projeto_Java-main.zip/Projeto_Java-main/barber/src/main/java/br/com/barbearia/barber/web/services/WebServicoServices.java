package br.com.barbearia.barber.web.services;

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.barbearia.barber.core.exceptions.ServicoNaoEncontradoException;
import br.com.barbearia.barber.core.models.Servico;
import br.com.barbearia.barber.core.repositories.ServicoRepository;
import br.com.barbearia.barber.web.dtos.ServicoForm;
import br.com.barbearia.barber.web.mappers.WebServicoMapper;

@Service
public class WebServicoServices {
  
  @Autowired
  private ServicoRepository repository;

  @Autowired
  private WebServicoMapper mapper;

    public List<Servico> buscarTodos() {
    return repository.findAll();
}

  public Servico cadastrar(ServicoForm form) {
    var model = mapper.toModel(form);
    model.setNomeImagem(form.getNomeImagem());

    return repository.save(model);
  }

  public Servico buscarPorId(Long CodSrv) {
    var ServicoEncontrado = repository.findById(CodSrv);

    if (ServicoEncontrado.isPresent()){
      return ServicoEncontrado.get();
    }

    var mensagem = String.format("Servico com ID %d não encontrado", CodSrv);
    throw new ServicoNaoEncontradoException(mensagem);
  }

  public Servico editar(ServicoForm form, Long CodSrv){
    var ServicoEncontrado = buscarPorId(CodSrv);

    var model = mapper.toModel (form);
    model.setCodSrv(ServicoEncontrado.getCodSrv());

    return repository.save(model);
  }

  public void excluirPorId(Long CodSrv){
    var ServicoEncontrado = buscarPorId(CodSrv);

    repository.delete(ServicoEncontrado);
  }

  
}
