package br.com.barbearia.barber.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import br.com.barbearia.barber.core.enums.TipoFuncionario;

@Configuration
public class SecurityConfiguration {

    @Autowired
    private UserDetailsService userDetailsService;

    @Autowired
    private PasswordEncoder passwordEncoder;

    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService)
                .passwordEncoder(passwordEncoder);
    }
    

    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                .antMatchers("/admin/funcionario/**").hasAuthority(TipoFuncionario.ADMIN.toString())
                .anyRequest().authenticated();

                http.formLogin()
                .loginPage("/admin/login.html")
                .usernameParameter("EmailFun")
                .passwordParameter("senha")
                .defaultSuccessUrl("/admin/servico")
                .permitAll();

                http.logout().logoutRequestMatcher(new AntPathRequestMatcher("/admin/logout", "GET"));
    }

     @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.authorizeRequests().antMatchers("/admin/funcionario/**").hasAuthority(TipoFuncionario.ADMIN.toString())
                .anyRequest().authenticated();
                http.formLogin()
                .loginPage("/admin/login.html")
                    .defaultSuccessUrl("/admin/servico")
                    .permitAll();
                http.logout().logoutRequestMatcher(new AntPathRequestMatcher("/admin/logout", "GET"))
                .permitAll();
                     
        return http.build();
    }
 
    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return (web) -> web.ignoring().antMatchers("/images/**", "/js/**", "/webjars/**");
    }
 
}
