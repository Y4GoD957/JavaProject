package br.com.barbearia.barber.web.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.barbearia.barber.web.dtos.FuncionarioCadastroForm;
import br.com.barbearia.barber.web.dtos.FuncionarioEdicaoForm;
import br.com.barbearia.barber.core.enums.TipoFuncionario;
import br.com.barbearia.barber.core.exceptions.ValidacaoException;
import br.com.barbearia.barber.web.dtos.FlashMessage;
import br.com.barbearia.barber.web.services.WebFuncionarioServices;

@Controller
@RequestMapping("/admin/funcionario")
public class FuncionarioController {

  @Autowired
  private WebFuncionarioServices service;

  @GetMapping
  public ModelAndView buscarTodos() {
    var modelAndView = new ModelAndView("admin/funcionario/lista");

    modelAndView.addObject("funcionario", service.buscarTodos());

    return modelAndView;
  }

  @GetMapping("/cadastrar")
  public ModelAndView cadastrar() {
    var modelAndView = new ModelAndView("admin/funcionario/cadastro-form");

    modelAndView.addObject("cadastroForm", new FuncionarioCadastroForm());

    return modelAndView;
  }

  @ModelAttribute("tipoFuncionarios")
  public TipoFuncionario[] getTipoFuncionario() {
    return TipoFuncionario.values();
  }

  @PostMapping("/cadastrar")
  public String cadastrar(@Valid @ModelAttribute("cadastroForm") FuncionarioCadastroForm cadastroForm, BindingResult result, RedirectAttributes attrs) {
    if (result.hasErrors()) {
      return "admin/funcionario/cadastro-form";
    }
    
    try {
      service.cadastrar(cadastroForm);
      attrs.addFlashAttribute("alert", new FlashMessage("alert-success", "funcionario cadastrado com sucesso!"));

    } catch (ValidacaoException e ) {
      result.addError(e.getFieldError());
      return "admin/funcionario/cadastro-form";
    }

    return "redirect:/admin/funcionario";
  }

  @GetMapping("/{CodFun}/editar")
  public ModelAndView editar(@PathVariable Long CodFun) {
    var modelAndView = new ModelAndView("admin/funcionario/editar-form");

    modelAndView.addObject("editarForm", service.buscarFormPorId(CodFun));

    return modelAndView;
  }

  @PostMapping("/{CodFun}/editar")
  public String editar(
     @PathVariable Long CodFun,
     @Valid @ModelAttribute("editarForm") FuncionarioEdicaoForm editarForm, 
     BindingResult result, 
     RedirectAttributes attrs
    ) {
      if (result.hasErrors()){
        return "admin/funcionario/editar-form";
      }
      try{
      service.editar(editarForm, CodFun);
      attrs.addFlashAttribute("alert", new FlashMessage("alert-success", "Funcionario editado com sucesso!"));
      } catch (ValidacaoException e ) {
      result.addError(e.getFieldError());
      return "admin/funcionario/editar-form";
    }
      return "redirect:/admin/funcionario";
  }

  @GetMapping("/{CodFun}/excluir")
  public String excluir(@PathVariable Long CodFun, RedirectAttributes attrs) {
    service.excluirPorId(CodFun);
    attrs.addFlashAttribute("alert", new FlashMessage("alert-success", "Funcionario excluido com sucesso!"));

    return "redirect:/admin/funcionario";
  }
  
}

