package br.com.barbearia.barber.core.enums;

public enum TipoFuncionario {
  ADMIN ("ADMIN"),
  CAIXA ("CAIXA"),
  BARBEIRO ("BARBEIRO");

  private String papel;

  private TipoFuncionario(String papel){
    this.papel = papel;
  }

  public String getPapel(){
    return papel;
  }
}
