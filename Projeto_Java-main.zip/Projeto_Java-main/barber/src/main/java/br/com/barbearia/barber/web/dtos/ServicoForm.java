package br.com.barbearia.barber.web.dtos;

import java.math.BigDecimal;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ServicoForm {

  @NotNull
  private String TipoSrv;
  
  @NotNull
  private BigDecimal ValorSrv;
  
  @NotNull
  private String DescSrv;
 
  private String NomeImagem;
}
