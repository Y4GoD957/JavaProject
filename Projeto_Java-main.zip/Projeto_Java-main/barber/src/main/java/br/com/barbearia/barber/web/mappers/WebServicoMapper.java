package br.com.barbearia.barber.web.mappers;

import org.springframework.stereotype.Component;

import br.com.barbearia.barber.core.models.Servico;
import br.com.barbearia.barber.web.dtos.ServicoForm;
 
@Component
public class WebServicoMapper {
  
  public Servico toModel(ServicoForm form) {
    if(form == null) {
      throw new IllegalArgumentException();
    }

    var model = new Servico();

    model.setTipoSrv(form.getTipoSrv());
    model.setValorSrv(form.getValorSrv());
    model.setDescSrv(form.getDescSrv());
    model.setNomeImagem(form.getNomeImagem());

    return model;
  }

  public ServicoForm toForm(Servico model) {
    if (model == null) {
      throw new IllegalArgumentException();
    }

    var form = new ServicoForm();

    form.setTipoSrv(model.getTipoSrv());
    form.setValorSrv(model.getValorSrv());
    form.setDescSrv(model.getDescSrv());
    form.setNomeImagem(model.getNomeImagem());

    return form;
  }
}
