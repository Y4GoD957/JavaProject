package br.com.barbearia.barber.web.dtos;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.br.CPF;

import br.com.barbearia.barber.core.enums.TipoFuncionario;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class FuncionarioEdicaoForm {
  
  @NotNull
  @Size(min = 3, max = 225)
  private String nomeCompleto;

  @NotNull
  @Size(min = 3, max = 225)
  @Email
  private String emailFun;

  @NotNull
  @Size(min = 9, max = 9)
  private String cepFun;

  @NotNull
  @CPF
  @Size(min = 11, max =14)
  private String cpfFun;

  @NotNull 
  @Size(min = 8, max =20) 
  private String foneFun;

  @NotNull
  private TipoFuncionario tipoFuncionario;
}
