package br.com.barbearia.barber.web.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.validation.FieldError;

import br.com.barbearia.barber.core.exceptions.FuncionarioJaCadastrado;
import br.com.barbearia.barber.core.exceptions.FuncionarioNaoEncontradoException;
import br.com.barbearia.barber.core.exceptions.SenhasNaoConferemException;
import br.com.barbearia.barber.core.models.Funcionario;
import br.com.barbearia.barber.core.repositories.FuncionarioRepository;
import br.com.barbearia.barber.web.dtos.FuncionarioCadastroForm;
import br.com.barbearia.barber.web.dtos.FuncionarioEdicaoForm;
import br.com.barbearia.barber.web.mappers.WebFuncionarioMapper;

@Service
public class WebFuncionarioServices {
  
  @Autowired
  private FuncionarioRepository repository;

  @Autowired
  private WebFuncionarioMapper mapper;

  @Autowired
  private PasswordEncoder passwordEncoder;

  public List<Funcionario> buscarTodos(){
    return repository.findAll();
  }

  public Funcionario cadastrar(FuncionarioCadastroForm form) {
   var senha = form.getSenha();
   var confirmacaoSenha = form.getConfirmacaoSenha();
   
   if (!senha.equals(confirmacaoSenha)) {
    var mensagem = "Os dois campos não conferem";
    var fieldError = new FieldError(form.getClass().getName(), "confirmacaoSenha", form.getConfirmacaoSenha(), false, null, null, mensagem);

    throw new SenhasNaoConferemException(mensagem, fieldError);
   }
       
    var model = mapper.toModel(form);
    var senhaHash = passwordEncoder.encode(model.getSenha());

    model.setSenha(senhaHash);
    
    validarCamposUnicos(model);

    return repository.save(model);
  }

  public Funcionario buscarPorId(Long CodFun) {
    var mensagem = String.format("Funcionario com ID %d não encontrado", CodFun);

    return repository.findById(CodFun)
    .orElseThrow(() -> new FuncionarioNaoEncontradoException(mensagem));
    
  }

  public FuncionarioEdicaoForm buscarFormPorId(Long CodFun){
    var funcionario = buscarPorId(CodFun);

    return mapper.toForm(funcionario);
  }

  public Funcionario editar(FuncionarioEdicaoForm form, Long CodFun){
    var funcionario =  buscarPorId(CodFun);

    var model = mapper.toModel(form);
    model.setCodFun(funcionario.getCodFun());
    model.setSenha(funcionario.getSenha());

    validarCamposUnicos(model);

    return repository.save(model);
  }

  public void excluirPorId(Long CodFun){
    var funcionario = buscarPorId(CodFun);

    repository.delete(funcionario);
  }

  private void validarCamposUnicos(Funcionario funcionario){
    if (repository.isEmailJaCadastrado(funcionario.getEmailFun(), funcionario.getCodFun())){
      var mensagem = "Já existe um funcionario cadastrado com este e-mail";
      var fieldError = new FieldError(funcionario.getClass().getName(), "EmailFun", funcionario.getEmailFun(), false, null, null, mensagem);

      throw new FuncionarioJaCadastrado(mensagem, fieldError);
    }
  }
}

