package br.com.barbearia.barber.web.dtos;

import java.math.BigDecimal;

import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Table(name = "PRODUTO")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ProdutoForm {

  @NotNull
  @Size(min = 3, max =90)
  private String NomePro;

  @NotNull
  private Integer QtdPro;

  @NotNull
  private BigDecimal ValorPro;

  @NotNull
  private String DescPro;
}
