package br.com.barbearia.barber.web.mappers;

import org.springframework.stereotype.Component;

import br.com.barbearia.barber.core.models.Funcionario;
import br.com.barbearia.barber.web.dtos.FuncionarioCadastroForm;
import br.com.barbearia.barber.web.dtos.FuncionarioEdicaoForm;
 
@Component
public class WebFuncionarioMapper {
  
  public Funcionario toModel(FuncionarioCadastroForm form) {
    if(form == null) {
      throw new IllegalArgumentException();
    }


    var model = new Funcionario();

    model.setNomeFun(form.getNomeCompleto());
    model.setEmailFun(form.getEmailFun());
    model.setSenha(form.getSenha());
    model.setCepFun(form.getCepFun());
    model.setCpfFun(form.getCpfFun());
    model.setFoneFun(form.getFoneFun());
    model.setTipoFuncionario(form.getTipoFuncionario());

    return model;
  }

  public Funcionario toModel( FuncionarioEdicaoForm form){
    if(form == null) {
      throw new IllegalArgumentException();
    }


    var model = new Funcionario();

    model.setNomeFun(form.getNomeCompleto());
    model.setEmailFun(form.getEmailFun());
    model.setCepFun(form.getCepFun());
    model.setCpfFun(form.getCpfFun());
    model.setFoneFun(form.getFoneFun());
    model.setTipoFuncionario(form.getTipoFuncionario());


    return model;
  }

  public FuncionarioEdicaoForm toForm(Funcionario model) {
    if (model == null) {
      throw new IllegalArgumentException();
    }

    FuncionarioEdicaoForm EForm = new FuncionarioEdicaoForm();

    EForm.setNomeCompleto(model.getNomeFun());
    EForm.setEmailFun(model.getEmailFun());
    EForm.setCepFun(model.getCepFun());
    EForm.setCpfFun(model.getCpfFun());
    EForm.setFoneFun(model.getFoneFun());
    EForm.setTipoFuncionario(model.getTipoFuncionario());

    return EForm;
  }
}
