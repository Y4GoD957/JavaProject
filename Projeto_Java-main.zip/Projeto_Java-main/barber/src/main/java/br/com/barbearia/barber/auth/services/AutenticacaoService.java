package br.com.barbearia.barber.auth.services;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import br.com.barbearia.barber.auth.models.FuncionarioAutenticado;
import br.com.barbearia.barber.core.repositories.FuncionarioRepository;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class AutenticacaoService implements UserDetailsService{

  @Autowired
  private FuncionarioRepository repository;

  @Override
  public UserDetails loadUserByUsername(String EmailFun) throws UsernameNotFoundException {
    var mensagem = String.format("Usuario com email %s não encontrado", EmailFun);

    return repository.findByEmailFun(EmailFun)
      .map(FuncionarioAutenticado::new)
      .orElseThrow(()-> new UsernameNotFoundException(mensagem));
  }
  
}
