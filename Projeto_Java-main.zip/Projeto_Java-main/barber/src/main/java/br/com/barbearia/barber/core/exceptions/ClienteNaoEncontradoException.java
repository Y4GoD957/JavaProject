package br.com.barbearia.barber.core.exceptions;

import javax.persistence.EntityNotFoundException;

public class ClienteNaoEncontradoException extends EntityNotFoundException {
  
  public ClienteNaoEncontradoException(String message){
    super(message);
  }
}
