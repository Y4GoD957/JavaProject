package br.com.barbearia.barber.core.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import br.com.barbearia.barber.core.models.Funcionario;

@Repository
public interface FuncionarioRepository extends JpaRepository<Funcionario, Long> {
  @Query("SELECT f FROM Funcionario f WHERE f.EmailFun = :emailFun")
  Optional<Funcionario> findByEmailFun(@Param("emailFun") String emailFun);

  @Query("SELECT count(*) > 0 FROM Funcionario f WHERE f.EmailFun = :EmailFun and (:CodFun is null or f.CodFun != :CodFun)")
  Boolean isEmailJaCadastrado(String EmailFun, Long CodFun);
}