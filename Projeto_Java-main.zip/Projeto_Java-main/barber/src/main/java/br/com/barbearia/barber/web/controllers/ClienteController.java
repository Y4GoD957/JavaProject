package br.com.barbearia.barber.web.controllers;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import br.com.barbearia.barber.web.dtos.ClienteForm;
import br.com.barbearia.barber.web.dtos.FlashMessage;
import br.com.barbearia.barber.web.services.WebClienteServices;

@Controller
@RequestMapping("/admin/cliente")
public class ClienteController {

  @Autowired
  private WebClienteServices service;

  @GetMapping
  public ModelAndView buscarTodos() {
    var modelAndView = new ModelAndView("admin/cliente/lista");

    modelAndView.addObject("cliente", service.buscarTodos());

    return modelAndView;
  }

  @GetMapping("/cadastrar")
  public ModelAndView cadastrar() {
    var modelAndView = new ModelAndView("admin/cliente/form.html");

    modelAndView.addObject("form", new ClienteForm());

    return modelAndView;
  }

  @PostMapping("/cadastrar")
  public String cadastrar(@Valid @ModelAttribute("form") ClienteForm form, BindingResult result, RedirectAttributes attrs) {
    if (result.hasErrors()) {
      return "admin/cliente/form.html";
    }
    
    service.cadastrar(form);
    attrs.addFlashAttribute("alert", new FlashMessage("alert-success", "Cliente cadastrado com sucesso!"));

    return "redirect:/admin/cliente";
  }

  @GetMapping("/{CodCli}/editar")
  public ModelAndView editar(@PathVariable Long CodCli) {
    var modelAndView = new ModelAndView("admin/cliente/form.html");

    modelAndView.addObject("form", service.buscarPorId(CodCli));

    return modelAndView;
  }

  @PostMapping("/{CodCli}/editar")
  public String editar(@PathVariable Long CodCli, @Valid @ModelAttribute("form") ClienteForm form, BindingResult result, RedirectAttributes attrs) {
   if (result.hasErrors()){
    return "admin/cliente/form.html";
   }

   service.editar(form, CodCli);
   attrs.addFlashAttribute("alert", new FlashMessage("alert-success", "Cliente editado com sucesso!"));

    return "redirect:/admin/cliente";
  }

  @GetMapping("/{CodCli}/excluir")
  public String excluir(@PathVariable Long CodCli, RedirectAttributes attrs) {
    service.excluirPorId(CodCli);
    attrs.addFlashAttribute("alert", new FlashMessage("alert-success", "Cliente excluido com sucesso!"));

    return "redirect:/admin/cliente";
  }

}
