package br.com.barbearia.barber.web.mappers;

import org.springframework.stereotype.Component;

import br.com.barbearia.barber.core.models.Produto;
import br.com.barbearia.barber.web.dtos.ProdutoForm;
 
@Component
public class WebProdutoMapper {
  
  public Produto toModel(ProdutoForm form) {
    if(form == null) {
      throw new IllegalArgumentException();
    }

    var model = new Produto();

    model.setNomePro(form.getNomePro());
    model.setQtdPro(form.getQtdPro());
    model.setValorPro(form.getValorPro());
    model.setDescPro(form.getDescPro());

    return model;
  }

  public ProdutoForm toForm(Produto model) {
    if (model == null) {
      throw new IllegalArgumentException();
    }

    var form = new ProdutoForm();

    form.setNomePro(model.getNomePro());
    form.setQtdPro(model.getQtdPro());
    form.setValorPro(model.getValorPro());
    form.setDescPro(model.getDescPro());

    return form;
  }
}
