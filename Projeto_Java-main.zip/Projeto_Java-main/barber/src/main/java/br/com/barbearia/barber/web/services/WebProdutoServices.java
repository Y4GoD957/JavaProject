package br.com.barbearia.barber.web.services;

import java.util.List; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.barbearia.barber.core.exceptions.ProdutoNaoEncontradoException;
import br.com.barbearia.barber.core.models.Produto;
import br.com.barbearia.barber.core.repositories.ProdutoRepository;
import br.com.barbearia.barber.web.dtos.ProdutoForm;
import br.com.barbearia.barber.web.mappers.WebProdutoMapper;

@Service
public class WebProdutoServices {
  
  @Autowired
  private ProdutoRepository repository;

  @Autowired
  private WebProdutoMapper mapper;

  public List<Produto> buscarTodos(){
    return repository.findAll();
  }

  public Produto cadastrar(ProdutoForm form) {
    var model = mapper.toModel(form);

    return repository.save(model);
  }

  public Produto buscarPorId(Long CodPro) {
    var ProdutoEncontrado = repository.findById(CodPro);

    if (ProdutoEncontrado.isPresent()){
      return ProdutoEncontrado.get();
    }

    var mensagem = String.format("Produto com ID %d não encontrado", CodPro);
    throw new ProdutoNaoEncontradoException(mensagem);
  }

  public Produto editar(ProdutoForm form, Long CodPro){
    var ProdutoEncontrado = buscarPorId(CodPro);

    var model = mapper.toModel (form);
    model.setCodPro(ProdutoEncontrado.getCodPro());

    return repository.save(model);
  }

  public void excluirPorId(Long CodPro){
    var ProdutoEncontrado = buscarPorId(CodPro);

    repository.delete(ProdutoEncontrado);
  }
}
