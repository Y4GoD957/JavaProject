package br.com.barbearia.barber.web.mappers;

import org.springframework.stereotype.Component;

import br.com.barbearia.barber.core.models.Cliente;
import br.com.barbearia.barber.web.dtos.ClienteForm;
 
@Component
public class WebClienteMapper {
  
  public Cliente toModel(ClienteForm form) {
    if(form == null) {
      throw new IllegalArgumentException();
    }

    var model = new Cliente();

    model.setNomeCli(form.getNomeCli());
    model.setEmailCli(form.getEmailCli());
    model.setCpfCli(form.getCpfCli());
    model.setFoneCli(form.getFoneCli());

    return model;
  }

  public ClienteForm toForm(Cliente model) {
    if (model == null) {
      throw new IllegalArgumentException();
    }

    var form = new ClienteForm();

    form.setNomeCli(model.getNomeCli());
    form.setEmailCli(model.getEmailCli());
    form.setCpfCli(model.getCpfCli());
    form.setFoneCli(model.getFoneCli());

    return form;
  }
}
